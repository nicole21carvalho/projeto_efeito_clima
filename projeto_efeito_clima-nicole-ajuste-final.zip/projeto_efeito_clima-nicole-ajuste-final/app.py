from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import streamlit as st

# ============================================================
# CONFIGURAÇÕES GERAIS
# ============================================================
ARQUIVO_CSV = Path(__file__).with_name("acidentes2025_todas_causas_tipos.csv")

COLUNAS_USADAS = [
    "id", "pesid", "data_inversa", "horario", "uf", "municipio",
    "causa_acidente", "tipo_acidente", "classificacao_acidente", "fase_dia",
    "condicao_metereologica", "id_veiculo", "ilesos", "feridos_leves",
    "feridos_graves", "mortos",
]

COLUNAS_TEXTO = [
    "uf", "municipio", "causa_acidente", "tipo_acidente",
    "classificacao_acidente", "fase_dia", "condicao_metereologica",
]

COLUNAS_VITIMAS = ["ilesos", "feridos_leves", "feridos_graves", "mortos"]
CLIMAS_ADVERSOS = {
    "chuva", "garoa/chuvisco", "chuvisco", "nevoeiro/neblina",
    "neblina", "nevoeiro", "vento", "granizo", "geada",
}


# ============================================================
# CONFIGURAÇÃO DA PÁGINA
# ============================================================
st.set_page_config(
    page_title="Efeito Clima nos Acidentes Rodoviários",
    page_icon="🌧️",
    layout="wide",
)

st.title("🌧️ O Efeito Clima nos Acidentes Rodoviários")
st.markdown(
    """
    **Problema:** qual é o impacto real da chuva na gravidade e no tipo de colisão
    em rodovias federais brasileiras?

    Este painel utiliza dados abertos da PRF para analisar acidentes únicos,
    evitando duplicações presentes no arquivo `acidentes2025_todas_causas_tipos.csv`.
    """
)


# ============================================================
# FUNÇÕES AUXILIARES
# ============================================================
def limpar_texto(serie: pd.Series) -> pd.Series:
    """Padroniza textos vazios e valores não informados."""
    return (
        serie.fillna("Não informado")
        .astype(str)
        .str.strip()
        .replace({"": "Não informado", "nan": "Não informado", "Não Informado": "Não informado"})
    )


def normalizar_sem_acentos(serie: pd.Series) -> pd.Series:
    """Remove acentos e deixa o texto em minúsculo para comparações."""
    return (
        serie.fillna("")
        .astype(str)
        .str.lower()
        .str.strip()
        .str.normalize("NFKD")
        .str.encode("ascii", errors="ignore")
        .str.decode("utf-8")
    )


def formatar_numero(valor: int | float) -> str:
    return f"{int(valor):,}".replace(",", ".")


def filtrar_por_ids(df_base: pd.DataFrame, df_referencia: pd.DataFrame) -> pd.DataFrame:
    return df_base[df_base["id"].isin(df_referencia["id"].unique())].copy()


def grafico_barras(serie: pd.Series, titulo: str, eixo_x: str, eixo_y: str) -> None:
    if serie.empty:
        st.info("Não há dados suficientes para gerar este gráfico.")
        return

    fig, ax = plt.subplots(figsize=(10, 5))
    serie.plot(kind="bar", ax=ax)
    ax.set_title(titulo)
    ax.set_xlabel(eixo_x)
    ax.set_ylabel(eixo_y)
    ax.tick_params(axis="x", rotation=45)
    fig.tight_layout()
    st.pyplot(fig)
    plt.close(fig)


# ============================================================
# CARREGAMENTO E PREPARAÇÃO DOS DADOS
# ============================================================
@st.cache_data(show_spinner="Carregando e preparando os dados...")
def carregar_dados() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if not ARQUIVO_CSV.exists():
        st.error(
            "CSV não encontrado. Coloque o arquivo "
            "'acidentes2025_todas_causas_tipos.csv' na mesma pasta deste app.py."
        )
        st.stop()

    df = pd.read_csv(
        ARQUIVO_CSV,
        sep=";",
        encoding="latin1",
        usecols=COLUNAS_USADAS,
        low_memory=False,
    )

    # Limpeza básica
    df = df.drop_duplicates()
    df["data_inversa"] = pd.to_datetime(df["data_inversa"], errors="coerce")
    df["hora"] = pd.to_datetime(df["horario"], format="%H:%M:%S", errors="coerce").dt.hour

    for coluna in COLUNAS_TEXTO:
        df[coluna] = limpar_texto(df[coluna])

    df["uf"] = df["uf"].str.upper()
    df = df.dropna(subset=["id", "data_inversa"])
    df = df[df["uf"].ne("Não informado")]

    for coluna in COLUNAS_VITIMAS:
        df[coluna] = pd.to_numeric(df[coluna], errors="coerce").fillna(0)

    # Base 1: uma linha por acidente
    base_acidentes = [
        "id", "data_inversa", "hora", "uf", "municipio",
        "condicao_metereologica", "classificacao_acidente", "fase_dia",
    ]
    acidentes = df[base_acidentes].drop_duplicates("id").copy()

    # Evita duplicar vítimas: uma pessoa pode aparecer em mais de uma linha do CSV
    pessoas = df.dropna(subset=["pesid"]).drop_duplicates(["id", "pesid"])
    vitimas = pessoas.groupby("id", as_index=False)[COLUNAS_VITIMAS].sum()
    acidentes = acidentes.merge(vitimas, on="id", how="left")

    # Evita duplicar veículos: um veículo pode aparecer em mais de uma linha do CSV
    veiculos = (
        df.dropna(subset=["id_veiculo"])
        .drop_duplicates(["id", "id_veiculo"])
        .groupby("id")
        .size()
        .reset_index(name="veiculos")
    )
    acidentes = acidentes.merge(veiculos, on="id", how="left")

    for coluna in COLUNAS_VITIMAS + ["veiculos"]:
        acidentes[coluna] = pd.to_numeric(acidentes[coluna], errors="coerce").fillna(0)

    # Features principais
    clima_normalizado = normalizar_sem_acentos(acidentes["condicao_metereologica"])
    acidentes["clima_adverso"] = np.where(clima_normalizado.isin(CLIMAS_ADVERSOS), "Adverso", "Normal")
    acidentes["total_feridos"] = acidentes["feridos_leves"] + acidentes["feridos_graves"]
    acidentes["indice_gravidade"] = (
        acidentes["mortos"] * 3
        + acidentes["feridos_graves"] * 2
        + acidentes["feridos_leves"]
    )

    # Base 2: uma linha por acidente + tipo
    tipos = (
        df[["id", "tipo_acidente", "condicao_metereologica"]]
        .drop_duplicates(["id", "tipo_acidente"])
        .merge(acidentes[["id", "clima_adverso"]], on="id", how="left")
    )

    # Base 3: uma linha por acidente + causa
    causas = df[["id", "causa_acidente"]].drop_duplicates(["id", "causa_acidente"])

    return acidentes, tipos, causas


acidentes, tipos, causas = carregar_dados()


# ============================================================
# FILTROS
# ============================================================
st.sidebar.header("🔎 Filtros")

data_min = acidentes["data_inversa"].min().date()
data_max = acidentes["data_inversa"].max().date()
periodo = st.sidebar.date_input("Período:", value=(data_min, data_max), min_value=data_min, max_value=data_max)

data_inicio, data_fim = periodo if isinstance(periodo, tuple) and len(periodo) == 2 else (data_min, data_max)

ufs = sorted(acidentes["uf"].dropna().unique())
climas = sorted(acidentes["condicao_metereologica"].dropna().unique())
classificacoes = sorted(acidentes["classificacao_acidente"].dropna().unique())

ufs_sel = st.sidebar.multiselect("Estado (UF):", ufs, default=ufs)
climas_sel = st.sidebar.multiselect("Condição meteorológica:", climas, default=climas)
classif_sel = st.sidebar.multiselect("Classificação do acidente:", classificacoes, default=classificacoes)

filtro = (
    acidentes["data_inversa"].between(pd.Timestamp(data_inicio), pd.Timestamp(data_fim))
    & acidentes["uf"].isin(ufs_sel)
    & acidentes["condicao_metereologica"].isin(climas_sel)
    & acidentes["classificacao_acidente"].isin(classif_sel)
)

acidentes_filtrados = acidentes[filtro].copy()
tipos_filtrados = filtrar_por_ids(tipos, acidentes_filtrados)
causas_filtradas = filtrar_por_ids(causas, acidentes_filtrados)

if acidentes_filtrados.empty:
    st.warning("Nenhum dado encontrado com os filtros selecionados.")
    st.stop()


# ============================================================
# INDICADORES
# ============================================================
st.subheader("📊 Indicadores Gerais")

col1, col2, col3, col4, col5 = st.columns(5)
col1.metric("Acidentes", formatar_numero(acidentes_filtrados["id"].nunique()))
col2.metric("Mortos", formatar_numero(acidentes_filtrados["mortos"].sum()))
col3.metric("Feridos", formatar_numero(acidentes_filtrados["total_feridos"].sum()))
col4.metric("Veículos", formatar_numero(acidentes_filtrados["veiculos"].sum()))
col5.metric("% Clima Adverso", f"{(acidentes_filtrados['clima_adverso'].eq('Adverso').mean() * 100):.1f}%")


# ============================================================
# GRÁFICOS
# ============================================================
st.subheader("1. Acidentes por Condição Meteorológica")
grafico_barras(
    acidentes_filtrados.groupby("condicao_metereologica")["id"].nunique().sort_values(ascending=False).head(10),
    "Top 10 condições meteorológicas com mais acidentes",
    "Condição meteorológica",
    "Acidentes únicos",
)

st.subheader("2. Gravidade Média por Condição Meteorológica")
grafico_barras(
    acidentes_filtrados.groupby("condicao_metereologica")["indice_gravidade"].mean().sort_values(ascending=False).head(10),
    "Índice de gravidade médio por clima",
    "Condição meteorológica",
    "Gravidade média",
)

st.subheader("3. Tipos de Acidente em Dias de Chuva/Garoa")
clima_tipos = normalizar_sem_acentos(tipos_filtrados["condicao_metereologica"])
tipos_chuva = (
    tipos_filtrados[clima_tipos.str.contains("chuva|garoa|chuvisco", na=False)]
    .groupby("tipo_acidente")["id"]
    .nunique()
    .sort_values(ascending=False)
    .head(10)
)
grafico_barras(tipos_chuva, "Tipos mais frequentes em chuva/garoa", "Tipo de acidente", "Acidentes únicos")

st.subheader("4. Acidentes por Hora do Dia")
por_hora = (
    acidentes_filtrados.dropna(subset=["hora"])
    .groupby(["hora", "clima_adverso"])["id"]
    .nunique()
    .unstack(fill_value=0)
)

if por_hora.empty:
    st.info("Não há dados de horário para os filtros selecionados.")
else:
    fig, ax = plt.subplots(figsize=(10, 5))
    por_hora.plot(kind="line", marker="o", ax=ax)
    ax.set_title("Distribuição de acidentes por hora")
    ax.set_xlabel("Hora do dia")
    ax.set_ylabel("Acidentes únicos")
    ax.legend(title="Clima")
    fig.tight_layout()
    st.pyplot(fig)
    plt.close(fig)

st.subheader("5. Estados com Mais Acidentes em Clima Adverso")
adversos = acidentes_filtrados[acidentes_filtrados["clima_adverso"].eq("Adverso")]
grafico_barras(
    adversos.groupby("uf")["id"].nunique().sort_values(ascending=False).head(10),
    "Top 10 estados com mais acidentes em clima adverso",
    "UF",
    "Acidentes únicos",
)

st.subheader("6. Causas Mais Frequentes em Clima Adverso")
causas_adversas = filtrar_por_ids(causas_filtradas, adversos)
ranking_causas = causas_adversas.groupby("causa_acidente")["id"].nunique().sort_values(ascending=False).head(10)
grafico_barras(ranking_causas, "Top 10 causas em clima adverso", "Causa", "Acidentes únicos")


# ============================================================
# TABELAS E CONCLUSÃO
# ============================================================
st.subheader("📋 Resumo por Condição Meteorológica")
resumo = (
    acidentes_filtrados.groupby("condicao_metereologica")
    .agg(
        acidentes=("id", "nunique"),
        mortos=("mortos", "sum"),
        feridos=("total_feridos", "sum"),
        veiculos=("veiculos", "sum"),
        gravidade_media=("indice_gravidade", "mean"),
    )
    .sort_values("acidentes", ascending=False)
)
st.dataframe(resumo, use_container_width=True)

st.subheader("📝 Conclusão")
clima_top = resumo.index[0] if not resumo.empty else "N/A"
tipo_chuva_top = tipos_chuva.index[0] if not tipos_chuva.empty else "N/A"
causa_top = ranking_causas.index[0] if not ranking_causas.empty else "N/A"
pct_adverso = acidentes_filtrados["clima_adverso"].eq("Adverso").mean() * 100

st.markdown(
    f"""
    Com base nos filtros selecionados:

    - A condição meteorológica com mais acidentes únicos foi **{clima_top}**.
    - Em chuva/garoa, o tipo de acidente mais frequente foi **{tipo_chuva_top}**.
    - Em clima adverso, a causa mais frequente foi **{causa_top}**.
    - O percentual de acidentes em clima adverso foi **{pct_adverso:.1f}%**.

    A análise considera acidentes únicos pela coluna **id**, vítimas únicas por **id + pesid**
    e veículos únicos por **id + id_veiculo**, evitando contagens duplicadas do CSV.
    """
)
